package com.github.mortlight.plugindemo.ui;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.editor.EditorSettings;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.TextBrowseFolderListener;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.psi.PsiPackage;
import com.intellij.ui.EditorTextField;
import com.intellij.ui.components.JBPanel;
import com.intellij.ui.components.JBScrollPane;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.intellij.ide.util.PackageChooserDialog;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class MainUI extends AnAction {
    private Project project;
    public JPanel contentPanel = new JBPanel<>();
    private JPanel mainPanel;
    private JPanel chooseFilePanel;
    private JTabbedPane tabbedPanel;
    private JPanel originPanel;
    private JButton originSubmitButton;
    private JButton mergeButton;
    private JButton submitButton;
    private JButton previewButton;
    private JButton applyButton;
    private EditorTextField originCodeTextArea;
    private JTextField mergeFileNameTextField;
    private JTextArea outputTextArea;
    private JTextArea conflictTextArea;
    private JLabel originChooseFilePathLabel;
    private JPanel branch1Panel;
    private JPanel branch2Panel;
    private TextFieldWithBrowseButton originTextFieldWithBrowseButton;
    private JLabel branch1ChooseFilePathLabel;
    private JLabel branch2ChooseFilePathLabel;
    private TextFieldWithBrowseButton branch1TextFieldWithBrowseButton;
    private JButton branch1SubmitButton;
    private EditorTextField branch1CodeTextArea;
    private JTextArea branch2CodeTextArea;
    private JButton branch2SubmitButton;
    private TextFieldWithBrowseButton branch2TextFieldWithBrowseButton;
    private TextFieldWithBrowseButton mergeFilePathTextFieldWithBrowseButton;
    private TextFieldWithBrowseButton chooseOriginTextFieldWithBrowseButton;
    private File originFile;
    private File branch1File;
    private File branch2File;

    public MainUI(){
        JScrollPane scrollPane = new JBScrollPane(originCodeTextArea);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        originTextFieldWithBrowseButton.addBrowseFolderListener(
                "Choose Origin File", "Choose origin file", project,
                FileChooserDescriptorFactory.createSingleFileDescriptor());
        branch1TextFieldWithBrowseButton.addBrowseFolderListener(
                "Choose Branch1 File", "Choose Branch1 file", project,
                FileChooserDescriptorFactory.createSingleFileDescriptor());
        branch2TextFieldWithBrowseButton.addBrowseFolderListener(
                "Choose Branch2 File", "Choose Branch2 file", project,
                FileChooserDescriptorFactory.createSingleFileDescriptor());
        originSubmitButton.addActionListener(e -> {
            try {
                String originContent = new String(Files.readAllBytes(Paths.get(originTextFieldWithBrowseButton.getText())));
                originCodeTextArea.setText(originContent);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        branch1SubmitButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            fileChooser.showOpenDialog(branch1Panel);
            branch1File = fileChooser.getSelectedFile();
            branch1TextFieldWithBrowseButton.setText(branch1File.getPath());
        });

        branch2SubmitButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            fileChooser.showOpenDialog(branch2Panel);
            branch2File = fileChooser.getSelectedFile();
            branch2TextFieldWithBrowseButton.setText(branch2File.getPath());
        });

        mergeButton.addActionListener(e -> {
            String command = "java -jar " + originFile.getAbsolutePath() + " " + branch1File.getAbsolutePath() + " " + branch2File.getAbsolutePath();

            try {
                ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
                Process process = processBuilder.start();
                process.waitFor();
                System.out.println("Command executed successfully.");
            } catch (IOException ex) {
                System.out.println("An error occurred while executing the command: " + ex.getMessage());
            } catch (InterruptedException ex) {
                System.out.println("Command execution was interrupted: " + ex.getMessage());
            }
        });

        submitButton.addActionListener(e -> {
            String fileName = mergeFileNameTextField.getText();
            String filePath = mergeFilePathTextFieldWithBrowseButton.getText();

            File file = new File(filePath, fileName);

            try {
                if (file.createNewFile()) {
                    System.out.println("File created successfully: " + file.getAbsolutePath());
                } else {
                    System.out.println("File creation failed. File already exists or an error occurred.");
                }
            } catch (IOException ex) {
                System.out.println("An error occurred while creating the file: " + ex.getMessage());
            }
        });


    }

    @Override
    public void actionPerformed(AnActionEvent anActionEvent) {

    }


    /*    private void createUIComponents() {
            // TODO: place custom component creation code here
        }

        public void createUI(Project project) {
            this.project = project;
            contentPanel.setLayout(new VerticalFlowLayout(VerticalFlowLayout.TOP));
            this.initChooseFilePanel();
            this.initPostfixPanel();
            this.initPackagePanel();
            this.initOptionsPanel();
            this.initClearCachePanel();
            this.reset();
        }

        private void initChooseFilePanel() {

        }*/
    public JComponent getComponent() {
        return mainPanel;
    }
}
